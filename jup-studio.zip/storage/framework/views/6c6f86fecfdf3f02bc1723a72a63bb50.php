<?php $__env->startSection('content'); ?>
    <div class="content">
        <!-- Start Content-->
        <div class="container-fluid">
            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.index')); ?>"><?php echo e(env('WEBSITE_NAME')); ?></a></li>
                                <li class="breadcrumb-item active">Quản lý liên hệ</li>
                            </ol>
                        </div>
                        <h4 class="page-title">Quản lý liên hệ</h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-12">
                    <div class="card-box">
                        <div class="table-responsive">
                            <table class="table table-centered mb-0">
                                <thead class="font-13 bg-light text-muted">
                                    <tr>
                                        <th class="font-weight-medium">Tên</th>
                                        <th class="font-weight-medium">Email</th>
                                        <th class="font-weight-medium">Số điện thoại</th>
                                        <th class="font-weight-medium">Ghi chú</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="text-muted font-13"><?php echo e($contact->name); ?></td>
                                            <td class="text-muted font-13"><?php echo e($contact->email); ?></td>
                                            <td class="text-muted font-13"><?php echo e($contact->phone); ?></td>
                                            <td class="text-muted font-13"><?php echo e($contact->note); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div> <!-- end col -->
            </div>
            <!-- end row -->

            <div class="row mt-3">
                <div class="col-12">
                    <div class="text-right">
                        <div class="d-flex justify-content-end">
                            <?php echo $contacts->links(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div> <!-- container -->
    </div> <!-- content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /usr/share/nginx/html/resources/views/admins/body/extras-contact.blade.php ENDPATH**/ ?>
<!-- Topbar Start -->
<div class="navbar-custom" style="background-color: #3bafda">
    <ul class="list-unstyled topnav-menu float-right mb-0">
        <li class="dropdown notification-list">
            <a class="nav-link dropdown-toggle nav-user mr-0 waves-effect waves-light" data-toggle="dropdown"
                href="#" role="button" aria-haspopup="false" aria-expanded="false">
                <img src="<?php echo e(asset('../bootstrap-admin/images/users/avatar-1.jpg')); ?>" alt="user-image"
                    class="rounded-circle">
                <span class="pro-user-name ml-1">
                    <?php echo e(auth()->user()->name); ?> <i class="mdi mdi-chevron-down"></i>
                </span>
            </a>
            <div class="dropdown-menu dropdown-menu-right profile-dropdown ">
                <!-- item-->
                <a href="javascript:void(0);" class="dropdown-item notify-item">
                    <i class="remixicon-account-circle-line"></i>
                    <span>Tài khoản của tôi</span>
                </a>

                <!-- item-->
                

                

                <!-- item-->


                <a href="<?php echo e(route('admin.logout')); ?>" class="dropdown-item notify-item"
                    onclick="event.preventDefault();
                    document.getElementById('logout-form').submit();">

                    <i class="remixicon-logout-box-line"></i>
                    <span>
                        Đăng xuất
                    </span>
                </a>
                <form method="POST" action="<?php echo e(route('admin.logout')); ?>" id="logout-form" style="display: none;">
                    <?php echo e(csrf_field()); ?>

                </form>
            </div>
        </li>
    </ul>
    <?php
        $pageImageLogo = App\Models\Page::where('slug', 'logo')->first();
    ?>
    <!-- LOGO -->
    <div class="logo-box" style="background-color: #3bafda">
        <a href="<?php echo e(route('admin.index')); ?>" class="logo text-center">
            <span class="logo-lg">
                <img src="<?php echo e(asset('../..' . Storage::url($pageImageLogo->image->url))); ?>" alt=""
                    height="70">
                <!-- <span class="logo-lg-text-light">Xeria</span> -->
            </span>
            <span class="logo-sm">
                <!-- <span class="logo-sm-text-dark">X</span> -->
                <img src="<?php echo e(asset('../..' . Storage::url($pageImageLogo->image->url))); ?>" alt=""
                    height="60">
            </span>
        </a>
    </div>

    <ul class="list-unstyled topnav-menu topnav-menu-left m-0">
        <li>
            <button class="button-menu-mobile waves-effect waves-light">
                <i class="fe-menu"></i>
            </button>
        </li>
    </ul>
</div>
<!-- end Topbar -->
<?php /**PATH /usr/share/nginx/html/resources/views/admins/body/topbar.blade.php ENDPATH**/ ?>
<!-- Loader -->
<div class="loader" id="loader-fade">
    <div class="loader-container">
        <ul class="loader-box">
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
        </ul>
    </div>
</div>
<!-- Loader ends -->
<?php /**PATH /usr/share/nginx/html/resources/views/clients/body/loader.blade.php ENDPATH**/ ?>
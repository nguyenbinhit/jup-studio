﻿
<?php $__env->startSection('content'); ?>
    <div class="content">
        <!-- Start Content-->
        <div class="container-fluid">
            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.index')); ?>"><?php echo e(env('WEBSITE_NAME')); ?></a></li>
                                <li class="breadcrumb-item active">Quản lý tập tin</li>
                            </ol>
                        </div>
                        <h4 class="page-title">Quản lý tập tin</h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-12">
                    <div class="card-box">
                        <div class="table-responsive">
                            <table class="table table-centered mb-0">
                                <thead class="font-13 bg-light text-muted">
                                    <tr>
                                        <th class="font-weight-medium">Tên tệp</th>
                                        <th class="font-weight-medium">Ngày tạo</th>
                                        <th class="font-weight-medium">Kích cỡ</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <img src="<?php echo e(asset('../..' . Storage::url($image->url))); ?>" height="30"
                                                    alt="<?php echo e($image->alt); ?>" class="mr-2">
                                                <a href="javascript:void(0);" class="text-dark"><?php echo e($image->name); ?></a>
                                            </td>
                                            <td class="text-muted font-13"><?php echo e($image->created_at); ?></td>

                                            <td>
                                                <?php
                                                    $sizeInBytes = $image->size;
                                                    $sizeInKB = round($sizeInBytes / 1024, 2);
                                                    $sizeInMB = round($sizeInKB / 1024, 2);
                                                    $displaySize = $sizeInMB > 1 ? $sizeInMB . 'MB' : $sizeInKB . 'KB';
                                                ?>
                                                <?php echo e($displaySize); ?>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div> <!-- end col -->
            </div>
            <!-- end row -->

            <div class="row mt-3">
                <div class="col-12">
                    <div class="text-right">
                        <div class="d-flex justify-content-end">
                            <?php echo $images->links(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div> <!-- container -->
    </div> <!-- content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /usr/share/nginx/html/resources/views/admins/body/apps-filemanager.blade.php ENDPATH**/ ?>
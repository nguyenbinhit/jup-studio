<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Minton - Responsive Admin Dashboard Template</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description">
    <meta content="Coderthemes" name="author">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- App favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('../bootstrap-admin/images/favicon.ico')); ?>">

    <!-- Summernote css -->
    <link href="<?php echo e(asset('../bootstrap-admin/libs/summernote/summernote-bs4.css')); ?>" rel="stylesheet" type="text/css">

    <!-- Plugins css -->
    <link href="<?php echo e(asset('../bootstrap-admin/libs/dropzone/dropzone.min.css')); ?>" rel="stylesheet" type="text/css">

    <!-- App css -->
    <link href="<?php echo e(asset('../bootstrap-admin/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('../bootstrap-admin/css/icons.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('../bootstrap-admin/css/app.min.css')); ?>" rel="stylesheet" type="text/css">

    <!-- Custom box css -->
    <link href="<?php echo e(asset('../bootstrap-admin/libs/custombox/custombox.min.css')); ?>" rel="stylesheet" type="text/css">
</head>

<body>
    <!-- Begin page -->
    <div id="wrapper">
        <?php echo $__env->make('admins.body.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('admins.body.left-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="content-page">
            <?php echo $__env->yieldContent('content'); ?>

            <!-- Footer Start -->
            <footer class="footer">
                <div class="container-fluid">
                    <div class="row">
                        2023 &copy; <a href="">Dashboard JUP Studio</a>
                    </div>
                </div>
            </footer>
            <!-- end Footer -->
        </div>


        <!-- ============================================================== -->
        <!-- End Page content -->
        <!-- ============================================================== -->
    </div>
    <!-- END wrapper -->

    <!-- Right bar overlay-->
    <div class="rightbar-overlay"></div>
    
    <script src="<?php echo e(asset('../bootstrap-admin/libs/custombox/custombox.min.js')); ?>"></script>

    <!-- Vendor js -->
    <script src="<?php echo e(asset('../bootstrap-admin/js/vendor.min.js')); ?>"></script>

    <script src="<?php echo e(asset('../bootstrap-admin/libs/jquery-knob/jquery.knob.min.js')); ?>"></script>
    <script src="<?php echo e(asset('../bootstrap-admin/libs/peity/jquery.peity.min.js')); ?>"></script>

    <!-- Sparkline charts -->
    <script src="<?php echo e(asset('../bootstrap-admin/libs/jquery-sparkline/jquery.sparkline.min.js')); ?>"></script>

    <!-- init js -->
    <script src="<?php echo e(asset('../bootstrap-admin/js/pages/dashboard-1.init.js')); ?>"></script>

    <!-- Summernote js -->
    <script src="<?php echo e(asset('../bootstrap-admin/libs/summernote/summernote-bs4.min.js')); ?>"></script>

    <!-- Init js -->
    <script src="<?php echo e(asset('../bootstrap-admin/js/pages/form-summernote.init.js')); ?>"></script>

    <!-- App js -->
    <script src="<?php echo e(asset('../bootstrap-admin/js/app.min.js')); ?>"></script>

    <?php echo $__env->yieldPushContent('script'); ?>
</body>

</html>
<?php /**PATH /usr/share/nginx/html/resources/views/admins/index.blade.php ENDPATH**/ ?>
<!-- Footer starts -->
<footer class="p-half bg-white" style="padding: 1rem 0">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 text-center">
                <ul class="footer-icons">
                    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($page->slug === 'social'): ?>
                            <?php $__currentLoopData = $page['metadata']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($key === 'facebook'): ?>
                                    <li>
                                        <a href="<?php echo e($value); ?>" target="_blank" class="wow fadeInUp facebook"><i
                                                class="fab fa-facebook-f"></i> </a>
                                    </li>
                                <?php endif; ?>

                                <?php if($key === 'twitter'): ?>
                                    <li><a href="<?php echo e($value); ?>" target="_blank" class="wow fadeInDown twitter"><i
                                                class="fab fa-twitter"></i> </a>
                                    </li>
                                <?php endif; ?>

                                <?php if($key === 'google'): ?>
                                    <li><a href="<?php echo e($value); ?>" target="_blank" class="wow fadeInUp google"><i
                                                class="fab fa-google"></i> </a>
                                    </li>
                                <?php endif; ?>

                                <?php if($key === 'instagram'): ?>
                                    <li><a href="<?php echo e($value); ?>" target="_blank" class="wow fadeInUp instagram"><i
                                                class="fab fa-instagram"></i>
                                        </a> </li>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <li><a href="javascript:void(0)" class="wow fadeInDown linkedin"><i class="fab fa-linkedin-in"></i>
                        </a>
                    </li>
                </ul>
                <p class="copyrights mt-2">© 2023 <?php echo e(env('WEBSITE_NAME')); ?></p>
            </div>
        </div>
    </div>
</footer>
<!-- Footer ends -->
<?php /**PATH /usr/share/nginx/html/resources/views/clients/body/footer.blade.php ENDPATH**/ ?>
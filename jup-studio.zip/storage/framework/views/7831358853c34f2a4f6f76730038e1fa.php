<!-- Clients start -->
<section id="clients" class="bg-white p-0 cursor-light no-transition">
    <h2 class="d-none"></h2>
    <div class="section-padding parallax-setting parallaxie parallax2">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="main-title wow fadeIn" data-wow-delay="300ms">
                        <h2 class="mb-0">Reviews<span class="color-pink"> Khách Hàng</span></h2>
                    </div>
                </div>
            </div>

            <div class="testimonial-images">
                <div class="owl-thumbs owl-dots d-lg-block d-none">
                    <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($key === 0): ?>
                            <div class="owl-dot animated-wrap active"><img
                                    src="<?php echo e(asset('../..' . Storage::url($review->image->url))); ?>" alt
                                    class="animated-element">
                            </div>
                        <?php else: ?>
                            <div class="owl-dot animated-wrap"><img
                                    src="<?php echo e(asset('../..' . Storage::url($review->image->url))); ?>" alt
                                    class="animated-element"></div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <div class="row align-items-center position-relative">
                <div class="col-md-12">
                    <div class="owl-carousel owl-theme testimonial-two hide-cursor mx-auto wow zoomIn"
                        data-wow-delay="400ms">
                        <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($key === 1): ?>
                                <div class="testimonial-item hide-cursor">
                                    <p class="color-black testimonial-para mb-15px">
                                        <?php echo e($review->comment); ?></p>
                                    <div class="testimonial-post">
                                        <a href="javascript:void(0)" class="post"><img
                                                src="<?php echo e(asset('../..' . Storage::url($review->image->url))); ?>"
                                                alt="image"></a>
                                        <div class="text-content">
                                            <h5 class="color-black text-capitalize"><?php echo e($review->customer_name); ?></h5>
                                            <p class="color-grey"> <?php echo e($review->customer_email); ?></p>

                                            <div class="rating">
                                                <?php switch($review->stars):
                                                    case (1): ?>
                                                        <i class="fa fa-star"></i>
                                                    <?php break; ?>

                                                    <?php case (2): ?>
                                                        <i class="fa fa-star"></i>
                                                        <i class="fa fa-star"></i>
                                                    <?php break; ?>

                                                    <?php case (3): ?>
                                                        <i class="fa fa-star"></i>
                                                        <i class="fa fa-star"></i>
                                                        <i class="fa fa-star"></i>
                                                    <?php break; ?>

                                                    <?php case (4): ?>
                                                        <i class="fa fa-star"></i>
                                                        <i class="fa fa-star"></i>
                                                        <i class="fa fa-star"></i>
                                                        <i class="fa fa-star"></i>
                                                    <?php break; ?>

                                                    <?php case (5): ?>
                                                        <i class="fa fa-star"></i>
                                                        <i class="fa fa-star"></i>
                                                        <i class="fa fa-star"></i>
                                                        <i class="fa fa-star"></i>
                                                        <i class="fa fa-star"></i>
                                                    <?php break; ?>

                                                    <?php default: ?>
                                                        <i class="fa fa-star"></i>
                                                <?php endswitch; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php else: ?>
                                <div class="testimonial-item">
                                    <p class="color-black testimonial-para mb-15px">
                                        <?php echo e($review->comment); ?></p>
                                    <div class="testimonial-post">
                                        <a href="javascript:void(0)" class="post"><img
                                                src="<?php echo e(asset('../..' . Storage::url($review->image->url))); ?>"
                                                alt="image"></a>
                                        <div class="text-content">
                                            <h5 class="color-black text-capitalize"><?php echo e($review->customer_name); ?></h5>
                                            <p class="color-grey"> <?php echo e($review->customer_email); ?></p>

                                            <div class="rating">
                                                <?php switch($review->stars):
                                                    case (1): ?>
                                                        <i class="fa fa-star"></i>
                                                    <?php break; ?>

                                                    <?php case (2): ?>
                                                        <i class="fa fa-star"></i>
                                                        <i class="fa fa-star"></i>
                                                    <?php break; ?>

                                                    <?php case (3): ?>
                                                        <i class="fa fa-star"></i>
                                                        <i class="fa fa-star"></i>
                                                        <i class="fa fa-star"></i>
                                                    <?php break; ?>

                                                    <?php case (4): ?>
                                                        <i class="fa fa-star"></i>
                                                        <i class="fa fa-star"></i>
                                                        <i class="fa fa-star"></i>
                                                        <i class="fa fa-star"></i>
                                                    <?php break; ?>

                                                    <?php case (5): ?>
                                                        <i class="fa fa-star"></i>
                                                        <i class="fa fa-star"></i>
                                                        <i class="fa fa-star"></i>
                                                        <i class="fa fa-star"></i>
                                                        <i class="fa fa-star"></i>
                                                    <?php break; ?>

                                                    <?php default: ?>
                                                        <i class="fa fa-star"></i>
                                                <?php endswitch; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Clients ends -->
<?php /**PATH /usr/share/nginx/html/resources/views/clients/body/client-start.blade.php ENDPATH**/ ?>
<!--About start-->
<?php
    $pageImageAbout = App\Models\Page::where('slug', 'gioi-thieu')->first();
?>
<section class="about pb-0 overflow-visible" id="about">
    <div class="container">
        <div class="row">

            <div class="col-lg-6 pr-5 mb-5 mb-lg-0 wow fadeInLeft">
                <div class="rare-box"></div>
                <img src="<?php echo e(asset('../..' . Storage::url($pageImageAbout->image->url))); ?>" class="about-img-small position-relative w-100"
                    alt>
            </div>
            <div class="col-lg-6 pl-6">
                <div class="main-title text-lg-left offset-md-1 mb-0 wow fadeInUp" data-wow-delay="300ms">
                    <h2 class="wow fadeInUp font-weight-light" data-wow-delay="400ms"> <?php echo e($pageImageAbout->title); ?></h2>

                    <?php
                        echo $pageImageAbout->description;
                    ?>

                    
                    
                </div>
            </div>

        </div>
    </div>
</section>
<!--About end-->
<?php /**PATH /usr/share/nginx/html/resources/views/clients/body/about-start.blade.php ENDPATH**/ ?>
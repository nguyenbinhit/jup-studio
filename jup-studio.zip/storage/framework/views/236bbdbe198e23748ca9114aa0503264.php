<?php $__env->startSection('content'); ?>
    <div class="content">

        <!-- Start Content-->
        <div class="container-fluid">
            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.index')); ?>"><?php echo e(env('WEBSITE_NAME')); ?></a></li>
                                <li class="breadcrumb-item active">Thành viên studio</li>
                            </ol>
                        </div>
                        <h4 class="page-title">Quản lý thành viên studio</h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-12">
                    <div class="card-box">
                        <div class="row">
                            <div class="col-lg-8">
                                <form class="form-inline">
                                    <div class="form-group">
                                        <label for="inputPassword2" class="sr-only">Tìm kiếm</label>
                                        <input type="text" class="form-control" id="search" name="s"
                                            placeholder="Tìm kiếm thành viên...">
                                    </div>
                                </form>
                            </div>
                            <div class="col-lg-4">
                                <div class="text-lg-right mt-3 mt-lg-0">
                                    <a href="<?php echo e(route('admin.employees.create')); ?>" class="btn btn-success waves-effect"
                                        data-animation="fadein" data-overlaycolor="#38414a"><i
                                            class="mdi mdi-plus-circle mr-1"></i> Thêm mới</a>
                                </div>
                            </div><!-- end col-->
                        </div> <!-- end row -->
                    </div> <!-- end card-box -->
                </div><!-- end col-->
            </div>
            <!-- end row -->

            <div class="row" id="row-list-employees">
                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4" id="list-employees">
                        <div class="text-center card-box ribbon-box">
                            <?php if($employee->status === 'publish'): ?>
                                <div class="ribbon-two ribbon-two-primary"><span>Công bố</span></div>
                            <?php else: ?>
                                <div class="ribbon-two ribbon-two-danger"><span>Ẩn công bố</span></div>
                            <?php endif; ?>
                            <div class="clearfix"></div>
                            <div class="pt-2 pb-2">
                                <img src="<?php echo e($employee->image?->url ? asset('../..' . Storage::url($employee->image->url)) : asset('../bootstrap-admin/images/users/avatar-9.jpg')); ?>"
                                    class="rounded-circle img-thumbnail avatar-xl" alt="profile-image">

                                
                                <h4 class="mt-3 font-17"><a
                                        href="<?php echo e(route('admin.employees.show', ['employee' => $employee->uuid])); ?>"
                                        class="text-dark"><?php echo e($employee->name); ?></a></h4>
                                <p class="text-muted"><?php echo e($employee->position); ?> <span> | </span> <span> <a href="#"
                                            class="text-pink"><?php echo e($employee->email); ?></a> </span></p>

                                <p class="text-muted font-13 mb-3">
                                    <?php
                                        echo $employee->description;
                                    ?>
                                </p>

                                <ul class="social-list list-inline mt-3 mb-0">
                                    <?php $__currentLoopData = $employee->socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($key === 'google' && $employee->socials['google']): ?>
                                            <li class="list-inline-item">
                                                <a href="javascript: void(0);"
                                                    class="social-list-item border-danger text-danger"><i
                                                        class="mdi mdi-google"></i></a>
                                            </li>
                                        <?php endif; ?>
                                        <?php if($key === 'facebook' && $employee->socials['facebook']): ?>
                                            <li class="list-inline-item">
                                                <a href="javascript: void(0);"
                                                    class="social-list-item border-purple text-purple"><i
                                                        class="mdi mdi-facebook"></i></a>
                                            </li>
                                        <?php endif; ?>
                                        <?php if($key === 'twitter' && $employee->socials['twitter']): ?>
                                            <li class="list-inline-item">
                                                <a href="javascript: void(0);"
                                                    class="social-list-item border-info text-info"><i
                                                        class="mdi mdi-twitter"></i></a>
                                            </li>
                                        <?php endif; ?>
                                        <?php if($key === 'github' && $employee->socials['github']): ?>
                                            <li class="list-inline-item">
                                                <a href="javascript: void(0);"
                                                    class="social-list-item border-secondary text-secondary"><i
                                                        class="mdi mdi-github-circle"></i></a>
                                            </li>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>

                            </div> <!-- end .padding -->
                        </div> <!-- end card-box-->
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="row mt-3">
                <div class="col-12">
                    <div class="text-right">
                        <div class="d-flex justify-content-end">
                            <?php echo $employees->links(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script type="text/javascript">
        $(document).ready(function() {
            function fetch_data_search(query) {
                $.ajax({
                    url: "<?php echo e(route('admin.employees.search')); ?>",
                    method: "GET",
                    data: {
                        s: query
                    },
                    dataType: 'json',
                    success: function(employees) {
                        // Clear the existing employee list
                        // $('#list-employees').remove();
                        var employeeHtml = '';

                        $.each(employees.data, function(index, employee) {
                            var url = '';
                            var imagePath = '';
                            if (employee.image && employee.image.url) {
                                var urls = (employee.image.url).split('/');
                                url = urls[1] + '/' + urls[2];
                                imagePath = `<?php echo e(asset('../..' . Storage::url('${url}'))); ?>`;
                            } else {
                                var imagePath =
                                    "<?php echo e(asset('../../bootstrap-admin/images/users/avatar-9.jpg')); ?>";
                            }

                            employeeHtml += `
                                <div class="col-lg-4" id="list-employees">
                                    <div class="text-center card-box ribbon-box">
                                        ${
                                            employee.status === 'publish' ?
                                            '<div class="ribbon-two ribbon-two-primary"><span>Công bố</span></div>' :
                                            '<div class="ribbon-two ribbon-two-danger"><span>Ẩn công bố</span></div>'
                                        }
                                        <div class="clearfix"></div>
                                        <div class="pt-2 pb-2">
                                            <img src="${imagePath}"
                                                class="rounded-circle img-thumbnail avatar-xl" alt="profile-image">

                                                <h4 class="mt-3 font-17"><a
                                                    class="text-dark">${employee.name}</a></h4>

                                                <p class="text-muted">${employee.position}<span> | </span> <span> <a href="#"
                                                    class="text-pink">${employee.email}</a> </span></p>

                                                <p class="text-muted font-13 mb-3">
                                                    ${employee.description}
                                                </p>

                                                <ul class="social-list list-inline mt-3 mb-0">
                                                    ${
                                                        employee.socials && employee.socials.google ?
                                                        '<li class="list-inline-item"><a href="javascript: void(0);" class="social-list-item border-danger text-danger"><i class="mdi mdi-google"></i></a></li>' :
                                                        ''
                                                    }
                                                    ${
                                                        employee.socials && employee.socials.facebook ?
                                                        '<li class="list-inline-item"><a href="javascript: void(0);" class="social-list-item border-danger text-danger"><i class="mdi mdi-facebook"></i></a></li>' :
                                                        ''
                                                    }
                                                    ${
                                                        employee.socials && employee.socials.twitter ?
                                                        '<li class="list-inline-item"><a href="javascript: void(0);" class="social-list-item border-danger text-danger"><i class="mdi mdi-twitter"></i></a></li>' :
                                                        ''
                                                    }
                                                    ${
                                                        employee.socials && employee.socials.github ?
                                                        '<li class="list-inline-item"><a href="javascript: void(0);" class="social-list-item border-danger text-danger"><i class="mdi mdi-github"></i></a></li>' :
                                                        ''
                                                    }
                                                </ul>
                                        </div>
                                    </div>
                                </div>
                            `;

                            $('#row-list-employees').html(employeeHtml);
                        });
                    }
                });
            }

            $(document).on('keyup', '#search', function() {
                var query = $(this).val();

                if (query) {
                    fetch_data_search(query);
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admins.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /usr/share/nginx/html/resources/views/admins/body/employee.blade.php ENDPATH**/ ?>
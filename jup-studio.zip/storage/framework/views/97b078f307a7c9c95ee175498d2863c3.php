<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="javascript: void(0);"><?php echo e(env('WEBSITE_NAME')); ?></a></li>
                                <li class="breadcrumb-item active">Quản lý trang tĩnh</li>
                            </ol>
                        </div>
                        <h4 class="page-title">Quản lý trang tĩnh</h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-12">
                    <div class="card-box">
                        <div class="table-responsive">
                            <table class="table table-borderless table-hover table-centered m-0">
                                <thead class="thead-light">
                                    <tr>
                                        <th>Hình ảnh</th>
                                        <th>Tên trang tĩnh</th>
                                        <th>Tiêu đề</th>
                                        <th>Nội dung</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <img src="<?php echo e($page->image?->url ? asset('../..' . Storage::url($page->image->url)) : asset('../bootstrapv1/img/about.jpg')); ?>"
                                                    class="img-thumbnail" alt="profile-image" style="width: 8rem">
                                            </td>
                                            <td>
                                                <h5 class="m-0 font-weight-normal"><?php echo e($page->name); ?></h5>
                                            </td>
                                            <td>
                                                <?php echo e($page->title); ?>

                                            </td>
                                            <td>
                                                <div
                                                    style="white-space: nowrap;
                                                width: 250px;
                                                overflow: hidden;
                                                text-overflow: ellipsis;">

                                                    <?php
                                                        echo $page->description;
                                                    ?>
                                                </div>

                                            </td>
                                            <td>
                                                <div class="row">
                                                    <div class="col-12 col-sm-6">
                                                        <a href="<?php echo e(route('admin.pages.edit', ['page' => $page->uuid])); ?>"
                                                            class="btn btn-xs btn-secondary"><i
                                                                class="mdi mdi-pencil"></i></a>
                                                    </div>
                                                    <div class="col-12 col-sm-6">
                                                        <a href="<?php echo e(route('client-home')); ?>" target="_blank"
                                                            class="btn btn-xs btn-secondary"><i class="mdi mdi-eye"></i></a>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div> <!-- end .table-responsive-->
                    </div> <!-- end card-box-->
                </div> <!-- end col -->
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /usr/share/nginx/html/resources/views/admins/body/page/index.blade.php ENDPATH**/ ?>
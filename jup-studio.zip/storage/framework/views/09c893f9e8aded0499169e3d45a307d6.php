<?php $__env->startSection('content'); ?>
    <div class="content">

        <!-- Start Content-->
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.index')); ?>"><?php echo e(env('WEBSITE_NAME')); ?></a>
                                </li>
                                <li class="breadcrumb-item active">Sản phẩm</li>
                            </ol>
                        </div>
                        <h4 class="page-title">Quản lý sản phẩm (Hình ảnh)</h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->
            <?php echo $__env->make('admins.body.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="row">
                <div class="col-12">
                    <div class="card-box">
                        
                        <form id="upload-form" action="<?php echo e(route('admin.pages.product.store')); ?>" method="POST"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <div class="fileupload btn btn-success waves-effect mb-3">
                                <span id="spinner" class="spinner-border spinner-border-sm mr-1" role="status"
                                    aria-hidden="true" style="display: none;"></span>
                                <span><i id="icon" class="mdi mdi-cloud-upload mr-1"></i> Tải lên hình ảnh</span>
                                <input type="file" name="file" id="file" class="upload">
                            </div>

                        </form>
                        <div class="table-responsive">
                            <table class="table table-centered mb-0">
                                <thead class="font-13 bg-light text-muted">
                                    <tr>
                                        <th class="font-weight-medium">Hình ảnh</th>
                                        <th class="font-weight-medium">Ngày tạo</th>
                                        <th class="font-weight-medium">Kích cỡ</th>
                                        <th class="font-weight-medium">Hành động</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <img src="<?php echo e(asset('../..' . Storage::url($product->image->url))); ?>"
                                                    height="30" alt="<?php echo e($product->image->alt); ?>" class="mr-2">
                                                <a href="javascript:void(0);" class="text-dark"><?php echo e($product->name); ?></a>
                                            </td>
                                            <td class="text-muted font-13"><?php echo e($product->created_at); ?></td>
                                            <td>
                                                <?php
                                                    $sizeInBytes = $product->image->size;
                                                    $sizeInKB = round($sizeInBytes / 1024, 2);
                                                    $sizeInMB = round($sizeInKB / 1024, 2);
                                                    $displaySize = $sizeInMB > 1 ? $sizeInMB . 'MB' : $sizeInKB . 'KB';
                                                ?>
                                                <?php echo e($displaySize); ?>

                                            </td>

                                            <td>
                                                <button
                                                    class="btn btn-xs btn-secondary btn-delete ml-2 d-flex d-flex justify-content-center"
                                                    data-product-id="<?php echo e($product->uuid); ?>">
                                                    <i class="mdi mdi-delete"></i></button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div> <!-- end col -->
            </div>
            <!-- end row -->

        </div> <!-- container -->

    </div> <!-- content -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script type="text/javascript">
        $(document).ready(function() {
            $('#file').change(function() {
                var form = $('#upload-form')[0];
                var formData = new FormData(form);

                var uploadButton = document.querySelector(".fileupload");
                uploadButton.setAttribute("disabled", "");

                var spinner = document.querySelector("#spinner");
                spinner.style.display = "inline-block";

                var icon = document.querySelector("#icon");
                icon.style.display = "none"

                $.ajax({
                    type: 'POST',
                    url: form.action,
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        const listProducts = "<?php echo e(route('admin.pages.product.index')); ?>";
                        window.location.href = listProducts;
                    },
                    error: function(error) {
                        console.log('Lỗi tải lên: ', error);
                    },
                    complete: function() {
                        uploadButton.removeAttribute("disabled");
                        spinner.style.display = "none";
                        icon.style.display = "inline-block"
                    }
                });
            });
            $('.btn-delete').click(function() {

                var button = $(this);
                var productId = button.data('product-id');

                $.ajax({
                    url: "<?php echo e(route('admin.pages.product.destroy', ':product_id')); ?>".replace(
                        ':product_id', productId),
                    type: 'DELETE',
                    data: {
                        '_token': "<?php echo e(csrf_token()); ?>",
                        'product_id': productId
                    },
                    success: function(response) {
                        button.closest('tr').remove();
                    },
                    error: function(error) {
                        console.log('Lỗi xóa sản phẩm: ', error);
                    }
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admins.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /usr/share/nginx/html/resources/views/admins/body/product/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content-login'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6 col-xl-5">
                <div class="card">
                    <div class="card-body p-4">
                        <div class="text-center w-75 m-auto">
                            <a href="index.html">
                                <span><img src="<?php echo e(asset('../bootstrapv1/img/logo.png')); ?>" alt="Jup Studio"
                                        height="100"></span>
                            </a>
                            <h3 class="text-muted mb-4 mt-3">Dashboard JUP Studio</h3>
                        </div>

                        <?php if(Session::has('error')): ?>
                            <div class="alert alert-danger text-center">
                                <strong><?php echo e(Session::get('error')); ?></strong>
                            </div>
                        <?php endif; ?>

                        <form action="<?php echo e(route('admin.login')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group mb-3">
                                <label for="emailaddress">Email address</label>
                                <input class="form-control <?php echo e($errors->has('email') ? 'mb-1 btn-danger' : ''); ?>" type="email"
                                    id="emailaddress" name="email" required="" placeholder="Enter your email">
                                <?php if($errors->has('email')): ?>
                                    <strong class="text-danger"><?php echo e($errors->first('email')); ?></strong>
                                <?php endif; ?>
                            </div>

                            <div class="form-group mb-3">
                                <label for="password">Password</label>
                                <input class="form-control <?php echo e($errors->has('email') ? 'mb-1 btn-danger' : ''); ?>" type="password"
                                    id="password" name="password" required="" placeholder="Enter your password">
                                <?php if($errors->has('password')): ?>
                                    <strong class="text-danger"><?php echo e($errors->first('password')); ?></strong>
                                <?php endif; ?>
                            </div>

                            <div class="d-flex justify-content-between align-items-center mb-4">
                                <div class="custom-control custom-checkbox">
                                    <input type="checkbox" class="custom-control-input" id="checkbox-signin" checked="">
                                    <label class="custom-control-label" for="checkbox-signin">Remember me</label>
                                </div>
                                
                            </div>

                            <div class="form-group mb-0 text-center">
                                <button class="btn btn-primary btn-block" type="submit"> Log In </button>
                            </div>
                        </form>
                    </div> <!-- end card-body -->
                </div>
                <!-- end card -->
            </div> <!-- end col -->
        </div>
        <!-- end row -->
    </div>
    <!-- end container -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.login.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /usr/share/nginx/html/resources/views/admins/login/index.blade.php ENDPATH**/ ?>
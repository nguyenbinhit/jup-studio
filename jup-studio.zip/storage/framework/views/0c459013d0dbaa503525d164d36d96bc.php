<?php if(Session::has('success')): ?>
    <div style="position: absolute; top: 8.5rem; right: 0; z-index: 10000; width: 300px;">
        <!-- Then put toasts within -->
        <div class="toast fade show ribbon-box" role="alert" aria-live="assertive" aria-atomic="true" data-toggle="toast">
            <div class="ribbon-two ribbon-two-primary"><span>Success</span></div>
            <div class="toast-header">
                <img src="<?php echo e(asset('../bootstrap-admin/images/users/avatar-4.jpg')); ?>" alt="brand-logo" height="28"
                    class="mr-1 rounded">
                <strong class="mr-auto"><?php echo e(auth()->user()->name); ?></strong>
                <small class="text-muted">vừa xong</small>
                <button onclick="removeSession()" class="ml-2 mb-1 close" data-dismiss="toast" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="toast-body" style="word-wrap: break-word;">
                <?php echo e(Session::get('success')); ?>

            </div>
        </div>
        <!--end toast-->
    </div>
<?php elseif(Session::get('error')): ?>
    <div style="position: absolute; top: 8.5rem; right: 0; z-index: 10000; width: 300px;">
        <!-- Then put toasts within -->
        <div class="toast fade show ribbon-box" role="alert" aria-live="assertive" aria-atomic="true"
            data-toggle="toast">
            <div class="ribbon-two ribbon-two-danger"><span>Danger</span></div>
            <div class="toast-header">
                <img src="<?php echo e(asset('../bootstrap-admin/images/users/avatar-4.jpg')); ?>" alt="brand-logo" height="28"
                    class="mr-1 rounded">
                <strong class="mr-auto"><?php echo e(auth()->user()->name); ?></strong>
                <small class="text-muted">vừa xong</small>
                <button onclick="removeSession()" class="ml-2 mb-1 close" data-dismiss="toast" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="toast-body" style="word-wrap: break-word;">
                <?php echo e(Session::get('error')); ?>

            </div>
        </div>
        <!--end toast-->
    </div>
<?php endif; ?>
<?php $__env->startPush('script'); ?>
    <script>
        function removeSession() {
            sessionStorage.removeItem('success');
            sessionStorage.removeItem('error');
            var removeSession = "<?php echo e(request()->session()->forget('success')); ?>";
            var removeSession = "<?php echo e(request()->session()->forget('error')); ?>";
            return;
        }
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH /usr/share/nginx/html/resources/views/admins/body/notification.blade.php ENDPATH**/ ?>
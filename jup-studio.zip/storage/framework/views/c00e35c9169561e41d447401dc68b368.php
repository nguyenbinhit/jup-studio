<?php $__env->startSection('content'); ?>
    <div class="content">

        <!-- Start Content-->
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.index')); ?>"><?php echo e(env('WEBSITE_NAME')); ?></a></li>
                                <li class="breadcrumb-item active">Trang chủ</li>
                            </ol>
                        </div>
                        <h4 class="page-title">Thông tin trang chủ</h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->

            <?php echo $__env->make('admins.body.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="row">
                <div class="col-lg-4 col-xl-4">
                    <div class="card-box text-center ribbon-box">

                        <div class="text-left mt-3">
                            <h4 class="font-13 text-uppercase">Thông tin trang chủ:</h4>

                            <p class="text-muted mb-2 font-13"><strong>Tên studio :</strong> <span
                                    class="ml-2"><?php echo e(isset($page->metadata['first']) ? $page->metadata['first'] : ''); ?></span>
                            </p>
                            </p>
                            <p class="text-muted mb-2 font-13"><strong>Kiểu studio :</strong> <span
                                    class="ml-2 "><?php echo e(isset($page->metadata['second']) ? $page->metadata['second'] : ''); ?></span>
                            </p>
                            </p>
                            <p class="text-muted mb-2 font-13"><strong>Slogan:</strong> <span
                                    class="ml-2 "><?php echo e(isset($page->metadata['third']) ? $page->metadata['third'] : ''); ?></span>
                            </p>
                            </p>

                            </p>
                        </div>
                    </div> <!-- end card-box -->
                </div> <!-- end col-->

                <div class="col-lg-8 col-xl-8">
                    <div class="card-box">
                        <ul class="nav nav-pills navtab-bg">
                            <li class="nav-item" style="margin-left: 19px;">
                                <a href="#" data-toggle="tab" aria-expanded="true" class="nav-link active">
                                    <i class="mdi mdi-settings-outline mr-1"></i>Cập nhật
                                </a>
                            </li>

                        </ul>
                        <!-- end card-->

                        <div class="card-body mt-1">
                            <h4 class="header-title m-t-0 mb-1">Thông tin trang chủ</h4>
                            <form action="<?php echo e(route('admin.pages.home.update', ['page' => 'trang-chu'])); ?>" method="POST"
                                enctype="multipart/form-data" novalidate="" class="needs-validation">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>

                                <div class="row">
                                    
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="first">Tên studio</label>
                                            <input type="text" class="form-control" id="first" name="metadata[first]"
                                                placeholder=""
                                                value="<?php echo e(isset($page->metadata['first']) && $page->metadata['first'] ? $page->metadata['first'] : ''); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="second">Kiểu studio</label>
                                            <input type="text" class="form-control" id="second"
                                                name="metadata[second]" placeholder=""
                                                value="<?php echo e(isset($page->metadata['second']) && $page->metadata['second'] ? $page->metadata['second'] : ''); ?>">

                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="third">Slogan</label>
                                            <textarea class="form-control" id="third" rows="6" name="metadata[third]" placeholder=""><?php echo e(isset($page->metadata['third']) && $page->metadata['third'] ? $page->metadata['third'] : ''); ?></textarea>
                                        </div>
                                    </div>
                                </div>
                                <?php if($errors->has('metadata')): ?>
                                    <div class="invalid-feedback text-danger">
                                        <?php echo e($errors->first('metadata')); ?>

                                    </div>
                                <?php endif; ?>
                                <div class="text-left">
                                    <button type="submit" class="btn btn-success mt-2"><i class="mdi mdi-content-save"></i>
                                        Lưu</button>
                                </div>
                            </form>
                        </div>
                    </div> <!-- end card-box-->
                    <!-- end row -->
                </div> <!-- end col -->
            </div>
            <!-- end row -->
        </div> <!-- container -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /usr/share/nginx/html/resources/views/admins/body/page/home.blade.php ENDPATH**/ ?>
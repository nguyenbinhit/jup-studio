 <!-- Blog start -->
 <section id="blog" class="half-section p-0 bg-change bg-yellow">
     <h2 class="d-none">heading</h2>
     <div class="container-fluid">
         <div class="row align-items-center">

             <div class="col-lg-6 col-md-12 p-0">
                 <div class="hover-effect">
                     <img alt="blog" src="{{ asset('../bootstrapv1/img/split-blog.jpg') }}" class="about-img">
                 </div>
             </div>

             <div class="col-lg-6 col-md-12 p-lg-0">
                 <div class="split-container-setting style-three text-center">
                     <div class="main-title mb-5 wow fadeIn" data-wow-delay="300ms">
                         <h5 class="font-18 text-blue"> Oct 12, 2019</h5>
                         <h2 class="mb-0 font-weight-normal"> Agency Blog
                         </h2>
                     </div>
                     <p class="color-black mb-5">Lorem ipsum dolor sit
                         amet, consectetur adipisicing elit, sed do
                         eiusmodt temp to the incididunt ut labore et
                         dolore magna aliqua. Ut enim ad minim veniam,
                         quis a nostr a exercitation ullamco laboris nisi
                         ut aliquip.</p>

                     <a href="creative-studio\blog.html"
                         class="btn-setting color-black btn-hvr-up btn-blue btn-hvr-pink">learn
                         more</a>
                 </div>
             </div>

         </div>
     </div>
 </section>
 <!-- Blog ends -->

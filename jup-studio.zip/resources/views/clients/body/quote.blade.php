<!-- Quote start -->
<section class="parallax-setting parallaxie parallax1">
    <h2 class="d-none">heading</h2>
    <div class="container">
        <div class="row align-items-center position-relative">
            <div class="col-md-12">
                <div class="quote-text text-center wow fadeInRight" data-wow-delay="300ms">
                    <div class="quote d-flex justify-content-start mb-2rem"><i class="fa fa-quote-left"></i></div>
                    <h2 class="font-weight-light mb-5 line-height-normal"><span class="color-yellow">Creativity</span>
                        is
                        allowing yourself to make mistakes Art is
                        knowing which ones to keep.</h2>
                    <h3 class="color-pink">Alice Johnson</h3>
                    <div class="quote d-flex justify-content-end mb-3"><i class="fa fa-quote-right"></i></div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Quote ends -->

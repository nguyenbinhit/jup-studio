<?php

namespace App\Enums;

enum EmployeeStatus: string
{
    case Publish = 'publish';
    case UnPublish = 'unpublish';
}
